import { useEffect, useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { ArrowUpRight, Bird, Egg, Wheat, ShoppingCart, CalendarClock, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { useRecordMutations, useRecords } from "@/lib/farm-data";
import { PRACTICES, ageInWeeks, feedStock, kes, quotaPercent, today, type Section } from "@/lib/practices";
import { DataTable, Field, NumberInput, Panel, Select, Stat, readForm } from "./ui";
import { selectedTreatment, TREATMENT_GROUPS } from "@/lib/treatments";

type Farm = Database["public"]["Tables"]["farms"]["Row"];
const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const n = Number;

function DateInput({ name = "date" }: { name?: string }) {
  return <Input type="date" name={name} defaultValue={today()} required />;
}

/* ---------------- Overview ---------------- */
export function Overview({ farm, onNavigate }: { farm: Farm; onNavigate: (section: Section) => void }) {
  const id = farm.id;
  const flocks = useRecords("flocks", id).data ?? [];
  const eggs = useRecords("egg_records", id).data ?? [];
  const sales = useRecords("sales", id).data ?? [];
  const feed = useRecords("feed_logs", id).data ?? [];
  const treatments = useRecords("treatments", id).data ?? [];
  const expenses = useRecords("expenses", id).data ?? [];
  const activities = useRecords("activities", id).data ?? [];
  const hasEggs = PRACTICES[farm.practice].sections.includes("eggs");

  const birds = flocks.reduce((s, f) => s + f.current_count, 0);
  const revenue = sales.reduce((s, r) => s + n(r.quantity) * n(r.unit_price), 0);
  const costs = expenses.reduce((s, e) => s + n(e.amount), 0) + feed.reduce((s, f) => s + n(f.cost), 0);
  const latestEgg = [...eggs].sort((a, b) => b.date.localeCompare(a.date))[0];
  const eggTrend = [...eggs].sort((a, b) => a.date.localeCompare(b.date)).slice(-14).map((e) => ({ date: e.date.slice(5), eggs: e.eggs, quota: e.quota }));
  const byProduct = Object.entries(sales.reduce<Record<string, number>>((m, s) => ((m[s.product] = (m[s.product] ?? 0) + n(s.quantity) * n(s.unit_price)), m), {})).map(([name, value]) => ({ name, value }));
  const upcoming = [
    ...treatments.filter((t) => !t.done).map((t) => ({ id: t.id, title: t.name, date: t.due_date, kind: "Treatment" })),
    ...activities.filter((a) => !a.done).map((a) => ({ id: a.id, title: a.title, date: a.date, kind: "Activity" })),
  ].sort((a, b) => a.date.localeCompare(b.date)).slice(0, 6);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={() => onNavigate("flock")}><Plus /> Add batch</Button>
        {hasEggs && <Button variant="outline" onClick={() => onNavigate("eggs")}><Egg /> Record eggs</Button>}
        <Button variant="outline" onClick={() => onNavigate("feed")}><Wheat /> Log feed</Button>
        <Button variant="outline" onClick={() => onNavigate("sales")}><ShoppingCart /> Record sale</Button>
      </div>
      {!flocks.length && <div className="flex flex-wrap items-center justify-between gap-4 border-l-4 border-accent bg-secondary/60 p-5">
        <div><h2 className="font-sans text-lg font-bold">Your first flock starts here</h2><p className="mt-1 text-sm text-muted-foreground">No batches recorded for {farm.name}.</p></div>
        <Button variant="outline" onClick={() => onNavigate("flock")}>Add first batch <ArrowUpRight /></Button>
      </div>}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Live birds" value={birds.toLocaleString()} hint={`${flocks.length} batch${flocks.length === 1 ? "" : "es"}`} />
        {hasEggs
          ? <Stat label="Eggs (last record)" value={latestEgg?.eggs ?? 0} hint={latestEgg ? `${quotaPercent(latestEgg.eggs, latestEgg.quota)}% of quota` : "No records"} />
          : <Stat label="Avg flock age" value={`${flocks.length ? Math.round(flocks.reduce((s, f) => s + ageInWeeks(f.arrival_date), 0) / flocks.length) : 0} wks`} />}
        <Stat label="Feed in store" value={`${feedStock(feed).toLocaleString()} kg`} />
        <Stat label="Profit" value={kes(revenue - costs)} hint={`${kes(revenue)} revenue`} />
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          {hasEggs ? (
            <Panel title="Egg production" action={<Button variant="ghost" size="sm" onClick={() => onNavigate("eggs")}>View records <ArrowUpRight /></Button>}>
              {!eggs.length ? <div className="flex h-60 flex-col items-center justify-center gap-3 text-muted-foreground"><Egg className="h-9 w-9 opacity-50" /><p className="text-sm">No egg collections yet</p><Button variant="outline" size="sm" onClick={() => onNavigate("eggs")}>Record collection</Button></div> : <ResponsiveContainer width="100%" height={260}>
                <LineChart data={eggTrend}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="date" fontSize={12} /><YAxis fontSize={12} /><Tooltip /><Legend />
                  <Line dataKey="eggs" stroke="var(--chart-1)" strokeWidth={2} /><Line dataKey="quota" stroke="var(--chart-2)" strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>}
            </Panel>
          ) : (
            <Panel title="Batch age (weeks)">
              {!flocks.length ? <div className="flex h-60 flex-col items-center justify-center gap-3 text-muted-foreground"><Bird className="h-9 w-9 opacity-50" /><p className="text-sm">No flock batches yet</p><Button variant="outline" onClick={() => onNavigate("flock")}>Add batch</Button></div> : <ResponsiveContainer width="100%" height={260}>
                <BarChart data={flocks.map((f) => ({ name: f.name, weeks: ageInWeeks(f.arrival_date), birds: f.current_count }))}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
                  <Bar dataKey="weeks" fill="var(--chart-1)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>}
            </Panel>
          )}
        </div>
        <Panel title="Revenue by product">
          {byProduct.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart><Pie data={byProduct} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90}>{byProduct.map((_, i) => <Cell key={i} fill={COLORS[i % 5]} />)}</Pie><Tooltip formatter={(v) => kes(n(v))} /><Legend /></PieChart>
            </ResponsiveContainer>
          ) : <div className="flex h-60 flex-col items-center justify-center gap-3 text-muted-foreground"><ShoppingCart className="h-9 w-9 opacity-50" /><p className="text-sm">No sales recorded</p><Button variant="outline" size="sm" onClick={() => onNavigate("sales")}>Record first sale</Button></div>}
        </Panel>
      </div>
      <Panel title="Coming up" action={<Button size="sm" variant="ghost" onClick={() => onNavigate("activities")}><CalendarClock /> Schedule</Button>}>
        <DataTable rows={upcoming} empty="Nothing scheduled." cols={[
          { h: "Date", c: (r) => <span className={r.date < today() ? "font-semibold text-destructive" : ""}>{r.date}</span> },
          { h: "Type", c: (r) => r.kind },
          { h: "Task", c: (r) => r.title },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Flock ---------------- */
export function FlockSection({ farm }: { farm: Farm }) {
  const flocks = useRecords("flocks", farm.id).data ?? [];
  const deaths = useRecords("mortalities", farm.id).data ?? [];
  const fm = useRecordMutations("flocks", farm.id);
  const mm = useRecordMutations("mortalities", farm.id);
  const name = (id: string) => flocks.find((f) => f.id === id)?.name ?? "—";
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Panel title="Add flock batch">
          <form className="grid gap-3" onSubmit={(e) => { const d = readForm(e); fm.add.mutate({ name: d.name, initial_count: n(d.count), current_count: n(d.count), arrival_date: d.date }, { onSuccess: d.reset }); }}>
            <Field label="Batch name"><Input name="name" required placeholder="e.g. Batch A – Jan" /></Field>
            <div className="grid grid-cols-2 gap-3"><Field label="Birds"><NumberInput name="count" step={1} /></Field><Field label="Arrival date"><DateInput /></Field></div>
            <Button type="submit" disabled={fm.add.isPending}>{fm.add.isPending ? "Saving…" : "Add batch"}</Button>
          </form>
        </Panel>
        <Panel title="Record mortality / reduction">
          <form className="grid gap-3" onSubmit={(e) => {
            const d = readForm(e); const f = flocks.find((x) => x.id === d.flock);
            if (!f) { toast.error("Choose a batch"); return; }
            if (n(d.count) > f.current_count) { toast.error(`Only ${f.current_count} birds in ${f.name}`); return; }
            mm.add.mutate({ flock_id: d.flock, count: n(d.count), reason: d.reason || null, date: d.date }, { onSuccess: d.reset });
          }}>
            <Field label="Batch"><Select name="flock" required>{flocks.map((f) => <option key={f.id} value={f.id}>{f.name} ({f.current_count})</option>)}</Select></Field>
            <div className="grid grid-cols-2 gap-3"><Field label="Birds"><NumberInput name="count" min={1} step={1} /></Field><Field label="Date"><DateInput /></Field></div>
            <Field label="Reason"><Select name="reason"><option>Died</option><option>Culled</option><option>Sold</option><option>Predator</option><option>Other</option></Select></Field>
            <Button type="submit" disabled={!flocks.length || mm.add.isPending}>Record</Button>
          </form>
        </Panel>
      </div>
      <Panel title="Batches">
        <DataTable rows={flocks} onDelete={(id) => fm.remove.mutate(id)} cols={[
          { h: "Batch", c: (r) => r.name },
          { h: "Arrived", c: (r) => r.arrival_date },
          { h: "Age", c: (r) => `${ageInWeeks(r.arrival_date)} wks`, right: true },
          { h: "Start", c: (r) => r.initial_count, right: true },
          { h: "Now", c: (r) => r.current_count, right: true },
          { h: "Survival", c: (r) => `${r.initial_count ? Math.round((r.current_count / r.initial_count) * 100) : 0}%`, right: true },
        ]} />
      </Panel>
      <Panel title="Mortality log">
        <DataTable rows={deaths} onDelete={(id) => mm.remove.mutate(id)} cols={[
          { h: "Date", c: (r) => r.date }, { h: "Batch", c: (r) => name(r.flock_id) }, { h: "Reason", c: (r) => r.reason ?? "—" }, { h: "Birds", c: (r) => r.count, right: true },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Eggs ---------------- */
export function EggSection({ farm }: { farm: Farm }) {
  const rows = useRecords("egg_records", farm.id).data ?? [];
  const m = useRecordMutations("egg_records", farm.id);
  const qc = useQueryClient();
  const [quota, setQuota] = useState(farm.egg_quota);
  useEffect(() => setQuota(farm.egg_quota), [farm.egg_quota]);
  const saveQuota = useMutation({
    mutationFn: async () => { const { error } = await supabase.from("farms").update({ egg_quota: quota }).eq("id", farm.id); if (error) throw error; },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["farm", farm.id] }); toast.success("Quota updated"); },
  });
  const total = rows.reduce((s, r) => s + r.eggs, 0);
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <Panel title="Daily quota">
          <div className="flex gap-2"><NumberInput value={quota} onChange={(e) => setQuota(n(e.target.value))} step={1} /><Button onClick={() => saveQuota.mutate()}>Save</Button></div>
          <p className="mt-2 text-xs text-muted-foreground">Target eggs per day across all hens.</p>
        </Panel>
        <Panel title="Record collection">
          <form className="grid gap-3" onSubmit={(e) => { const d = readForm(e); m.add.mutate({ eggs: n(d.eggs), quota: farm.egg_quota, date: d.date }, { onSuccess: d.reset }); }}>
            <div className="grid grid-cols-2 gap-3"><Field label="Eggs"><NumberInput name="eggs" step={1} /></Field><Field label="Date"><DateInput /></Field></div>
            <Button type="submit" disabled={m.add.isPending}>{m.add.isPending ? "Saving…" : "Save"}</Button>
          </form>
        </Panel>
        <Stat label="Total collected" value={total.toLocaleString()} hint={`≈ ${Math.floor(total / 30)} crates`} />
      </div>
      <Panel title="Production history">
        <DataTable rows={rows} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Date", c: (r) => r.date }, { h: "Eggs", c: (r) => r.eggs, right: true }, { h: "Quota", c: (r) => r.quota, right: true },
          { h: "Achieved", c: (r) => <span className={quotaPercent(r.eggs, r.quota) >= 100 ? "font-semibold text-success" : ""}>{quotaPercent(r.eggs, r.quota)}%</span>, right: true },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Sales ---------------- */
export function SalesSection({ farm }: { farm: Farm }) {
  const rows = useRecords("sales", farm.id).data ?? [];
  const m = useRecordMutations("sales", farm.id);
  const total = rows.reduce((s, r) => s + n(r.quantity) * n(r.unit_price), 0);
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2"><Panel title="Record a sale">
          <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => { const d = readForm(e); m.add.mutate({ product: d.product, quantity: n(d.qty), unit_price: n(d.price), date: d.date }, { onSuccess: d.reset }); }}>
            <Field label="Product"><Select name="product">{PRACTICES[farm.practice].products.map((p) => <option key={p}>{p}</option>)}</Select></Field>
            <Field label="Date"><DateInput /></Field>
            <Field label="Quantity"><NumberInput name="qty" min={0.01} /></Field>
            <Field label="Price per unit (KES)"><NumberInput name="price" /></Field>
            <Button type="submit" disabled={m.add.isPending} className="sm:col-span-2">Save sale</Button>
          </form>
        </Panel></div>
        <Stat label="Total revenue" value={kes(total)} hint={`${rows.length} sales`} />
      </div>
      <Panel title="Sales log">
        <DataTable rows={rows} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Date", c: (r) => r.date }, { h: "Product", c: (r) => r.product }, { h: "Qty", c: (r) => n(r.quantity), right: true },
          { h: "Price", c: (r) => kes(n(r.unit_price)), right: true }, { h: "Total", c: (r) => kes(n(r.quantity) * n(r.unit_price)), right: true },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Feed ---------------- */
export function FeedSection({ farm }: { farm: Farm }) {
  const rows = useRecords("feed_logs", farm.id).data ?? [];
  const m = useRecordMutations("feed_logs", farm.id);
  const types = farm.practice === "broilers" ? ["Starter", "Grower", "Finisher"] : farm.practice === "layers" ? ["Chick mash", "Growers mash", "Layers mash"] : ["Chick mash", "Growers mash", "Kienyeji mash", "Grain/scraps"];
  const stockByType = useMemo(() => types.map((t) => ({ type: t, kg: feedStock(rows.filter((r) => r.feed_type === t)) })), [rows]); // eslint-disable-line react-hooks/exhaustive-deps
  const FeedForm = ({ kind }: { kind: "purchase" | "consumption" }) => (
    <form className="grid gap-3" onSubmit={(e) => {
      const d = readForm(e);
      if (kind === "consumption" && n(d.qty) > (stockByType.find((s) => s.type === d.type)?.kg ?? 0)) { toast.error("Not enough of that feed in store"); return; }
      m.add.mutate({ kind, feed_type: d.type, quantity_kg: n(d.qty), cost: n(d.cost || 0), date: d.date }, { onSuccess: d.reset });
    }}>
      <Field label="Feed type"><Select name="type">{types.map((t) => <option key={t}>{t}</option>)}</Select></Field>
      <div className="grid grid-cols-2 gap-3"><Field label="Kg"><NumberInput name="qty" min={0.1} /></Field><Field label="Date"><DateInput /></Field></div>
      {kind === "purchase" && <Field label="Cost (KES)"><NumberInput name="cost" /></Field>}
      <Button type="submit" disabled={m.add.isPending}>{kind === "purchase" ? "Add to store" : "Record use"}</Button>
    </form>
  );
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <Panel title="Feed purchased"><FeedForm kind="purchase" /></Panel>
        <Panel title="Daily consumption"><FeedForm kind="consumption" /></Panel>
        <Panel title="In store">
          <ul className="space-y-2 text-sm">{stockByType.map((s) => <li key={s.type} className="flex justify-between"><span>{s.type}</span><b className="tabular-nums">{s.kg} kg</b></li>)}</ul>
        </Panel>
      </div>
      <Panel title="Feed logs">
        <DataTable rows={rows} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Date", c: (r) => r.date }, { h: "Type", c: (r) => (r.kind === "purchase" ? "Purchase" : "Used") }, { h: "Feed", c: (r) => r.feed_type },
          { h: "Kg", c: (r) => n(r.quantity_kg), right: true }, { h: "Cost", c: (r) => (n(r.cost) ? kes(n(r.cost)) : "—"), right: true },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Treatments ---------------- */
export function TreatmentSection({ farm }: { farm: Farm }) {
  const rows = useRecords("treatments", farm.id).data ?? [];
  const flocks = useRecords("flocks", farm.id).data ?? [];
  const m = useRecordMutations("treatments", farm.id);
  const [treatment, setTreatment] = useState("");
  const sorted = [...rows].sort((a, b) => Number(a.done) - Number(b.done) || a.due_date.localeCompare(b.due_date));
  return (
    <div className="space-y-6">
      <Panel title="Schedule a vaccine or treatment">
        <form className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 sm:items-end" onSubmit={(e) => {
          const d = readForm(e);
          let name: string;
          try { name = selectedTreatment(treatment, d.name || ""); } catch (error) { toast.error(error instanceof Error ? error.message : "Choose a treatment"); return; }
          m.add.mutate({ name, flock_name: d.flock || null, due_date: d.date }, { onSuccess: () => { d.reset(); setTreatment(""); } });
        }}>
          <div className="space-y-3"><Field label="Treatment"><Select aria-label="Treatment" required value={treatment} onChange={(e) => setTreatment(e.target.value)} disabled={m.add.isPending}>
            <option value="" disabled>Choose treatment</option>
            {TREATMENT_GROUPS.map((group) => <optgroup key={group.label} label={group.label}>{group.options.map((name) => <option key={name} value={name}>{name}</option>)}</optgroup>)}
            <option value="other">Other / custom treatment</option>
          </Select></Field>
          {treatment === "other" && <Field label="Treatment name"><Input name="name" aria-label="Treatment name" required pattern=".*\S.*" placeholder="Enter treatment name" disabled={m.add.isPending} /></Field>}</div>
          <Field label="Batch"><Select name="flock"><option value="">All birds</option>{flocks.map((f) => <option key={f.id}>{f.name}</option>)}</Select></Field>
          <Field label="Due date"><DateInput /></Field>
          <Button type="submit" disabled={m.add.isPending}>{m.add.isPending ? "Saving…" : "Schedule"}</Button>
        </form>
      </Panel>
      <Panel title="Treatment schedule">
        <DataTable rows={sorted} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Done", c: (r) => <Checkbox checked={r.done} onCheckedChange={(v) => m.update.mutate({ id: r.id, values: { done: !!v } })} aria-label="Mark done" /> },
          { h: "Due", c: (r) => <span className={!r.done && r.due_date < today() ? "font-semibold text-destructive" : ""}>{r.due_date}</span> },
          { h: "Treatment", c: (r) => <span className={r.done ? "line-through opacity-60" : ""}>{r.name}</span> },
          { h: "Batch", c: (r) => r.flock_name ?? "All" },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Finance ---------------- */
export function FinanceSection({ farm }: { farm: Farm }) {
  const rows = useRecords("expenses", farm.id).data ?? [];
  const sales = useRecords("sales", farm.id).data ?? [];
  const feed = useRecords("feed_logs", farm.id).data ?? [];
  const m = useRecordMutations("expenses", farm.id);
  const revenue = sales.reduce((s, r) => s + n(r.quantity) * n(r.unit_price), 0);
  const feedCost = feed.reduce((s, r) => s + n(r.cost), 0);
  const other = rows.reduce((s, r) => s + n(r.amount), 0);
  const monthly = useMemo(() => {
    const map: Record<string, { month: string; revenue: number; costs: number }> = {};
    const get = (d: string) => (map[d.slice(0, 7)] ??= { month: d.slice(0, 7), revenue: 0, costs: 0 });
    sales.forEach((s) => (get(s.date).revenue += n(s.quantity) * n(s.unit_price)));
    feed.forEach((f) => (get(f.date).costs += n(f.cost)));
    rows.forEach((e) => (get(e.date).costs += n(e.amount)));
    return Object.values(map).sort((a, b) => a.month.localeCompare(b.month)).slice(-6);
  }, [sales, feed, rows]);
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-4">
        <Stat label="Revenue" value={kes(revenue)} /><Stat label="Feed costs" value={kes(feedCost)} /><Stat label="Other costs" value={kes(other)} />
        <Stat label="Net profit" value={<span className={revenue - feedCost - other < 0 ? "text-destructive" : "text-success"}>{kes(revenue - feedCost - other)}</span>} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Add expense">
          <form className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => { const d = readForm(e); m.add.mutate({ category: d.category, description: d.description || null, amount: n(d.amount), date: d.date }, { onSuccess: d.reset }); }}>
            <Field label="Category"><Select name="category"><option>Chicks</option><option>Medicine</option><option>Labour</option><option>Equipment</option><option>Utilities</option><option>Other</option></Select></Field>
            <Field label="Amount (KES)"><NumberInput name="amount" /></Field>
            <Field label="Description"><Input name="description" /></Field>
            <Field label="Date"><DateInput /></Field>
            <Button type="submit" disabled={m.add.isPending} className="sm:col-span-2">Save expense</Button>
          </form>
        </Panel>
        <Panel title="Monthly revenue vs costs">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthly}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} /><Tooltip formatter={(v) => kes(n(v))} /><Legend />
              <Bar dataKey="revenue" fill="var(--chart-1)" radius={[6, 6, 0, 0]} /><Bar dataKey="costs" fill="var(--chart-3)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
      <Panel title="Expenses">
        <DataTable rows={rows} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Date", c: (r) => r.date }, { h: "Category", c: (r) => r.category }, { h: "Description", c: (r) => r.description ?? "—" }, { h: "Amount", c: (r) => kes(n(r.amount)), right: true },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Activities ---------------- */
export function ActivitySection({ farm }: { farm: Farm }) {
  const rows = useRecords("activities", farm.id).data ?? [];
  const m = useRecordMutations("activities", farm.id);
  const sorted = [...rows].sort((a, b) => Number(a.done) - Number(b.done) || a.date.localeCompare(b.date));
  return (
    <div className="space-y-6">
      <Panel title="Schedule activity">
        <form className="grid gap-3 sm:grid-cols-5 sm:items-end" onSubmit={(e) => { const d = readForm(e); m.add.mutate({ title: d.title, description: d.description || null, date: d.date, time: d.time || null }, { onSuccess: d.reset }); }}>
          <Field label="Title"><Input name="title" required placeholder="e.g. Clean drinkers" /></Field>
          <Field label="Notes"><Input name="description" /></Field>
          <Field label="Date"><DateInput /></Field>
          <Field label="Time"><Input type="time" name="time" /></Field>
          <Button type="submit" disabled={m.add.isPending}>{m.add.isPending ? "Saving…" : "Add"}</Button>
        </form>
      </Panel>
      <Panel title="Scheduled activities">
        <DataTable rows={sorted} onDelete={(id) => m.remove.mutate(id)} cols={[
          { h: "Done", c: (r) => <Checkbox checked={r.done} onCheckedChange={(v) => m.update.mutate({ id: r.id, values: { done: !!v } })} aria-label="Mark done" /> },
          { h: "When", c: (r) => `${r.date}${r.time ? " " + r.time.slice(0, 5) : ""}` },
          { h: "Activity", c: (r) => <span className={r.done ? "line-through opacity-60" : ""}>{r.title}</span> },
          { h: "Notes", c: (r) => r.description ?? "—" },
        ]} />
      </Panel>
    </div>
  );
}

/* ---------------- Profile ---------------- */
export function ProfileSection({ farm, onDeleted }: { farm: Farm; onDeleted: () => void }) {
  const qc = useQueryClient();
  const save = useMutation({
    mutationFn: async (v: Partial<Farm>) => { const { error } = await supabase.from("farms").update(v).eq("id", farm.id); if (error) throw error; },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["farm", farm.id] }); qc.invalidateQueries({ queryKey: ["farms"] }); toast.success("Profile saved"); },
    onError: (e: Error) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async () => { const { error } = await supabase.from("farms").delete().eq("id", farm.id); if (error) throw error; },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["farms"] }); onDeleted(); },
  });
  return (
    <div className="max-w-2xl space-y-6">
      <Panel title="Farm profile">
        <form key={farm.id + farm.name} className="grid gap-3 sm:grid-cols-2" onSubmit={(e) => {
          e.preventDefault(); const d = Object.fromEntries(new FormData(e.currentTarget)) as Record<"name" | "location" | "size" | "established" | "contact", string>;
          save.mutate({ name: d.name, location: d.location || null, size: d.size || null, established: d.established || null, contact: d.contact || null });
        }}>
          <Field label="Farm name"><Input name="name" required defaultValue={farm.name} /></Field>
          <Field label="Location"><Input name="location" defaultValue={farm.location ?? ""} /></Field>
          <Field label="Farm size"><Input name="size" placeholder="e.g. 1/4 acre" defaultValue={farm.size ?? ""} /></Field>
          <Field label="Established"><Input type="date" name="established" defaultValue={farm.established ?? ""} /></Field>
          <div className="sm:col-span-2"><Field label="Contact"><Input name="contact" defaultValue={farm.contact ?? ""} /></Field></div>
          <Button type="submit" className="sm:col-span-2">Save profile</Button>
        </form>
      </Panel>
      <Panel title="Danger zone">
        <Button variant="destructive" onClick={() => confirm(`Delete ${farm.name} and all its records?`) && del.mutate()}>Delete this farm</Button>
      </Panel>
    </div>
  );
}
