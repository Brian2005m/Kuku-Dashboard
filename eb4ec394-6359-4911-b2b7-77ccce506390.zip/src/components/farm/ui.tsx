import { useId, useState, type ReactNode } from "react";
import { Download, Search, Trash2, ClipboardList } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function Panel({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="min-w-0 border-t pt-5">
      <div className="mb-4 flex items-center justify-between gap-2">
        <h3 className="text-lg font-bold">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="min-w-0 rounded-lg border bg-card p-5">
      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-2 break-words font-sans text-2xl font-bold tabular-nums">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  const id = useId();
  return (
    <div className="space-y-1.5" role="group" aria-labelledby={id}>
      <Label id={id} className="text-xs uppercase tracking-wide text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

export function NumberInput(props: React.ComponentProps<typeof Input>) {
  return <Input type="number" inputMode="decimal" min={0} step="any" required {...props} />;
}

export const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
  <select
    {...props}
    className="flex h-9 w-full rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
  />
);

export function DataTable<T extends { id: string }>({
  rows,
  cols,
  onDelete,
  empty = "No records yet.",
}: {
  rows: T[];
  cols: { h: string; c: (r: T) => ReactNode; right?: boolean }[];
  onDelete?: (id: string) => void;
  empty?: string;
}) {
  const [search, setSearch] = useState("");
  const searchable = (r: T) => Object.values(r).filter((v) => typeof v === "string" || typeof v === "number").join(" ").toLowerCase();
  const visible = rows.filter((r) => searchable(r).includes(search.toLowerCase()));
  const exportCsv = () => {
    const keys = Object.keys(rows[0] ?? {}).filter((k) => !["id", "farm_id", "user_id", "created_at"].includes(k));
    const cell = (v: unknown) => '"' + String(v ?? "").replace(/^[=+@\-\t\r]/, "'$&").replaceAll('"', '""') + '"';
    const csv = [keys.map(cell).join(","), ...visible.map((r) => keys.map((k) => cell((r as Record<string, unknown>)[k])).join(","))].join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" }));
    const a = document.createElement("a"); a.href = url; a.download = `kuku-records-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); URL.revokeObjectURL(url);
  };
  if (!rows.length) return <div className="flex flex-col items-center gap-2 py-10 text-muted-foreground"><ClipboardList className="h-7 w-7 opacity-50" /><p className="text-sm">{empty}</p></div>;
  return (
    <div className="min-w-0">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative min-w-0 flex-1 sm:max-w-xs"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input aria-label="Search records" placeholder="Search records…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" /></div>
        <Button variant="outline" size="sm" onClick={exportCsv} disabled={!visible.length}><Download /> Export CSV</Button>
      </div>
      <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
            {cols.map((c) => <th key={c.h} className={`py-2 pr-3 font-semibold ${c.right ? "text-right" : ""}`}>{c.h}</th>)}
            {onDelete && <th className="w-8" />}
          </tr>
        </thead>
        <tbody>
          {visible.map((r) => (
            <tr key={r.id} className="border-b last:border-0 hover:bg-muted/50">
              {cols.map((c) => <td key={c.h} className={`py-2.5 pr-3 ${c.right ? "text-right tabular-nums" : ""}`}>{c.c(r)}</td>)}
              {onDelete && (
                <td>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Delete"
                    onClick={() => confirm("Delete this record?") && onDelete(r.id)}
                  >
                    <Trash2 className="text-destructive" />
                  </Button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">{visible.length} of {rows.length} records</p>
    </div>
  );
}

/** Keep input intact on validation or network errors; reset only after saving. */
type FieldName = "name" | "count" | "date" | "flock" | "reason" | "eggs" | "product" | "qty" | "price" | "type" | "cost" | "category" | "description" | "amount" | "title" | "time";
export function readForm(e: React.FormEvent<HTMLFormElement>): Record<FieldName, string> & { reset: () => void } {
  e.preventDefault();
  const form = e.currentTarget;
  const data = Object.fromEntries(new FormData(form)) as Record<FieldName, string>;
  return { ...data, reset: () => form.reset() };
}
