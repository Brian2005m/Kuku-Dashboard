export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      activities: {
        Row: {
          created_at: string
          date: string
          description: string | null
          done: boolean
          farm_id: string
          id: string
          time: string | null
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          date: string
          description?: string | null
          done?: boolean
          farm_id: string
          id?: string
          time?: string | null
          title: string
          user_id?: string
        }
        Update: {
          created_at?: string
          date?: string
          description?: string | null
          done?: boolean
          farm_id?: string
          id?: string
          time?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "activities_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      egg_records: {
        Row: {
          created_at: string
          date: string
          eggs: number
          farm_id: string
          id: string
          quota: number
          user_id: string
        }
        Insert: {
          created_at?: string
          date?: string
          eggs: number
          farm_id: string
          id?: string
          quota?: number
          user_id?: string
        }
        Update: {
          created_at?: string
          date?: string
          eggs?: number
          farm_id?: string
          id?: string
          quota?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "egg_records_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          date: string
          description: string | null
          farm_id: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          category: string
          created_at?: string
          date?: string
          description?: string | null
          farm_id: string
          id?: string
          user_id?: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          date?: string
          description?: string | null
          farm_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      farms: {
        Row: {
          contact: string | null
          created_at: string
          egg_quota: number
          established: string | null
          id: string
          location: string | null
          name: string
          practice: Database["public"]["Enums"]["practice_type"]
          size: string | null
          user_id: string
        }
        Insert: {
          contact?: string | null
          created_at?: string
          egg_quota?: number
          established?: string | null
          id?: string
          location?: string | null
          name: string
          practice: Database["public"]["Enums"]["practice_type"]
          size?: string | null
          user_id?: string
        }
        Update: {
          contact?: string | null
          created_at?: string
          egg_quota?: number
          established?: string | null
          id?: string
          location?: string | null
          name?: string
          practice?: Database["public"]["Enums"]["practice_type"]
          size?: string | null
          user_id?: string
        }
        Relationships: []
      }
      feed_logs: {
        Row: {
          cost: number
          created_at: string
          date: string
          farm_id: string
          feed_type: string
          id: string
          kind: string
          quantity_kg: number
          user_id: string
        }
        Insert: {
          cost?: number
          created_at?: string
          date?: string
          farm_id: string
          feed_type: string
          id?: string
          kind: string
          quantity_kg: number
          user_id?: string
        }
        Update: {
          cost?: number
          created_at?: string
          date?: string
          farm_id?: string
          feed_type?: string
          id?: string
          kind?: string
          quantity_kg?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "feed_logs_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      flocks: {
        Row: {
          arrival_date: string
          created_at: string
          current_count: number
          farm_id: string
          id: string
          initial_count: number
          name: string
          user_id: string
        }
        Insert: {
          arrival_date?: string
          created_at?: string
          current_count: number
          farm_id: string
          id?: string
          initial_count: number
          name: string
          user_id?: string
        }
        Update: {
          arrival_date?: string
          created_at?: string
          current_count?: number
          farm_id?: string
          id?: string
          initial_count?: number
          name?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "flocks_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      mortalities: {
        Row: {
          count: number
          created_at: string
          date: string
          farm_id: string
          flock_id: string
          id: string
          reason: string | null
          user_id: string
        }
        Insert: {
          count: number
          created_at?: string
          date?: string
          farm_id: string
          flock_id: string
          id?: string
          reason?: string | null
          user_id?: string
        }
        Update: {
          count?: number
          created_at?: string
          date?: string
          farm_id?: string
          flock_id?: string
          id?: string
          reason?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mortalities_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mortalities_flock_id_fkey"
            columns: ["flock_id"]
            isOneToOne: false
            referencedRelation: "flocks"
            referencedColumns: ["id"]
          },
        ]
      }
      sales: {
        Row: {
          created_at: string
          date: string
          farm_id: string
          id: string
          product: string
          quantity: number
          unit_price: number
          user_id: string
        }
        Insert: {
          created_at?: string
          date?: string
          farm_id: string
          id?: string
          product: string
          quantity: number
          unit_price: number
          user_id?: string
        }
        Update: {
          created_at?: string
          date?: string
          farm_id?: string
          id?: string
          product?: string
          quantity?: number
          unit_price?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
      treatments: {
        Row: {
          created_at: string
          done: boolean
          due_date: string
          farm_id: string
          flock_name: string | null
          id: string
          name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          done?: boolean
          due_date: string
          farm_id: string
          flock_name?: string | null
          id?: string
          name: string
          user_id?: string
        }
        Update: {
          created_at?: string
          done?: boolean
          due_date?: string
          farm_id?: string
          flock_name?: string | null
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "treatments_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      practice_type: "layers" | "broilers" | "kienyeji"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      practice_type: ["layers", "broilers", "kienyeji"],
    },
  },
} as const
