import { describe, expect, it } from "vitest";
import { selectedTreatment } from "@/lib/treatments";

describe("scheduled treatment selection", () => {
  it("stores the chosen treatment", () => { expect(selectedTreatment("Gumboro vaccine", "")).toBe("Gumboro vaccine"); });
  it("stores a custom treatment name rather than the other label", () => { expect(selectedTreatment("other", "  Vet-prescribed treatment  ")).toBe("Vet-prescribed treatment"); });
  it("rejects blank custom names and empty selection", () => { expect(() => selectedTreatment("other", " ")).toThrow(); expect(() => selectedTreatment("", "")).toThrow(); });
});