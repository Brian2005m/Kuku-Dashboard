import { describe, expect, it } from "vitest";
import { PRACTICES, ageInWeeks, feedStock, quotaPercent } from "@/lib/practices";

describe("practice rules", () => {
  it("broilers have no egg section; layers and kienyeji do", () => {
    expect(PRACTICES.broilers.sections).not.toContain("eggs");
    expect(PRACTICES.layers.sections).toContain("eggs");
    expect(PRACTICES.kienyeji.sections).toContain("eggs");
  });
  it("feed stock is purchases minus consumption, floored at 0", () => {
    expect(feedStock([{ kind: "purchase", quantity_kg: 70 }, { kind: "consumption", quantity_kg: 20 }])).toBe(50);
    expect(feedStock([{ kind: "consumption", quantity_kg: 5 }])).toBe(0);
  });
  it("quota percent and flock age", () => {
    expect(quotaPercent(90, 100)).toBe(90);
    expect(quotaPercent(10, 0)).toBe(0);
    expect(ageInWeeks("2026-01-01", new Date("2026-01-15T12:00:00"))).toBe(2);
  });
});
