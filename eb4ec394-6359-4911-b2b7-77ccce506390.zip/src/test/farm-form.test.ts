import { describe, expect, it, vi } from "vitest";
import { readForm } from "@/components/farm/ui";

describe("record form preservation", () => {
  it("retains entered values until the successful-save callback resets them", () => {
    const form = document.createElement("form");
    const input = document.createElement("input");
    input.name = "name";
    form.append(input);
    input.value = "November flock";
    const result = readForm({ preventDefault: vi.fn(), currentTarget: form } as unknown as React.FormEvent<HTMLFormElement>);
    expect(result.name).toBe("November flock");
    expect(input.value).toBe("November flock");
    result.reset();
    expect(input.value).toBe("");
  });
});