import { createFileRoute, Link } from "@tanstack/react-router";
import { Egg, ClipboardList, LineChart, Syringe } from "lucide-react";
import hero from "@/assets/farm-hero.jpg";
import { Button } from "@/components/ui/button";
import { PRACTICES, type Practice } from "@/lib/practices";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Kuku Ledger — Digitize your chicken tracking system" },
      { name: "description", content: "One dashboard for layers, broilers and kienyeji: flock, eggs, feed, treatments, sales and profit." },
      { property: "og:title", content: "Kuku Ledger — Digitize your chicken farm" },
      { property: "og:description", content: "Sign up, pick your chicken practice and start tracking today." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen">
      <header className="absolute inset-x-0 top-0 z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5 text-primary-foreground">
        <div className="flex items-center gap-2 font-display text-xl font-bold"><Egg className="h-6 w-6 text-accent" /> Kuku Ledger</div>
        <Button asChild variant="hero" size="sm"><Link to="/auth">Sign in</Link></Button>
      </header>

      <section className="relative isolate overflow-hidden bg-hero text-primary-foreground">
        <img src={hero} alt="Hens foraging outside a wooden coop" width={1600} height={1008} className="absolute inset-0 -z-10 h-full w-full object-cover opacity-35" />
        <div className="mx-auto max-w-6xl px-6 pb-24 pt-36">
          <p className="mb-4 inline-block rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">Built for Kenyan poultry farmers</p>
          <h1 className="max-w-3xl text-5xl font-bold leading-[1.05] md:text-7xl">Digitize your chicken tracking system.</h1>
          <p className="mt-6 max-w-xl text-lg opacity-90">Swap the notebook for one dashboard — flock counts, eggs, feed, vaccines, sales and profit, tailored to how you farm.</p>
          <Button asChild variant="hero" size="lg" className="mt-8"><Link to="/auth">Sign up free</Link></Button>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="text-3xl font-bold md:text-4xl">Choose your practice</h2>
        <p className="mt-2 text-muted-foreground">Your dashboard adapts to the kind of chickens you keep.</p>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {(Object.keys(PRACTICES) as Practice[]).map((k) => (
            <Link key={k} to="/auth" className="group rounded-2xl border bg-card p-6 shadow-soft transition hover:-translate-y-1">
              <div className="text-4xl">{PRACTICES[k].emoji}</div>
              <h3 className="mt-4 text-2xl font-bold">{PRACTICES[k].label}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{PRACTICES[k].tagline}</p>
              <span className="mt-4 inline-block text-sm font-semibold text-primary group-hover:underline">Start tracking →</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-secondary">
        <div className="mx-auto grid max-w-6xl gap-8 px-6 py-16 md:grid-cols-3">
          {[
            { icon: ClipboardList, t: "Every record, saved", d: "Your data is stored securely in your account — not lost when you clear the browser." },
            { icon: Syringe, t: "Never miss a vaccine", d: "Treatment schedules and farm activities with due-date reminders on your dashboard." },
            { icon: LineChart, t: "Know your profit", d: "Sales, feed and expenses roll up into clear charts and a running profit figure." },
          ].map(({ icon: I, t, d }) => (
            <div key={t}>
              <I className="h-7 w-7 text-primary" />
              <h3 className="mt-3 text-xl font-bold">{t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>
      <footer className="py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} Kuku Ledger</footer>
    </div>
  );
}
