import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Activity, ArrowLeftRight, Bird, CalendarClock, Egg, LayoutDashboard, LogOut, Settings, ShoppingCart, Syringe, Wallet, Wheat, Menu, X, ChevronRight, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useFarm } from "@/lib/farm-data";
import { PRACTICES, SECTION_LABELS, type Section } from "@/lib/practices";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import farmPhoto from "@/assets/farm-hero.jpg";
import { ActivitySection, EggSection, FeedSection, FinanceSection, FlockSection, Overview, ProfileSection, SalesSection, TreatmentSection } from "@/components/farm/sections";

export const Route = createFileRoute("/_authenticated/farm/$farmId")({
  head: () => ({ meta: [
    { title: "Farm dashboard — Kuku Ledger" },
    { name: "description", content: "Track flock, eggs, feed, treatments, sales and profit." },
    { property: "og:title", content: "Farm dashboard — Kuku Ledger" },
    { property: "og:description", content: "Track flock, eggs, feed, treatments, sales and profit." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: FarmDashboard,
});
const ICONS: Record<Section, typeof Egg> = {
  overview: LayoutDashboard, flock: Bird, eggs: Egg, sales: ShoppingCart, feed: Wheat,
  treatments: Syringe, finance: Wallet, activities: CalendarClock, profile: Settings,
};
function FarmDashboard() {
  const { farmId } = Route.useParams();
  const navigate = useNavigate();
  const { data: farm, isLoading, error, refetch } = useFarm(farmId);
  const [section, setSection] = useState<Section>("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const selectSection = (s: Section) => { setSection(s); setMenuOpen(false); window.scrollTo({ top: 0, behavior: "instant" }); };
  if (isLoading) return <div className="grid min-h-screen place-items-center text-muted-foreground"><Activity className="animate-pulse" aria-label="Loading farm" /></div>;
  if (error || !farm) return <div className="grid min-h-screen place-items-center text-center"><div><h1 className="text-xl font-semibold">Farm could not be loaded</h1><div className="mt-4 flex gap-3"><Button variant="outline" onClick={() => refetch()}>Try again</Button><Button asChild><Link to="/farms">My farms</Link></Button></div></div></div>;
  const p = PRACTICES[farm.practice];
  const props = { farm };
  return (
    <div className="min-h-screen md:grid md:grid-cols-[224px_minmax(0,1fr)]">
      <div className="sticky top-0 z-30 flex items-center justify-between border-b bg-card px-4 py-3 md:hidden">
        <div className="flex items-center gap-2 font-display text-lg font-bold"><Egg className="h-5 w-5 text-primary" /> Kuku Ledger</div>
        <Button size="icon" variant="ghost" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button>
      </div>
      <aside className={cn("z-20 bg-sidebar text-sidebar-foreground md:sticky md:top-0 md:flex md:h-screen md:flex-col", menuOpen ? "fixed inset-x-0 bottom-0 top-[61px] flex flex-col" : "hidden")}>
        <Link to="/farms" className="flex items-center gap-2 border-b border-sidebar-border px-5 py-6 font-display text-xl font-bold"><Egg className="h-6 w-6 text-sidebar-primary" /> Kuku Ledger</Link>
        <div className="m-4 flex items-center gap-3 border-b border-sidebar-border pb-4"><img src={farmPhoto} alt="Poultry on a farm" className="h-11 w-11 shrink-0 rounded-md object-cover" /><div className="min-w-0"><div className="truncate text-sm font-bold">{farm.name}</div><div className="mt-1 text-xs opacity-70">{p.label} practice</div></div></div>
        <nav aria-label="Farm sections" className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 pb-4">
          {p.sections.map((s) => { const I = ICONS[s]; return <Button key={s} variant="ghost" onClick={() => selectSection(s)} aria-current={section === s ? "page" : undefined} className={cn("h-10 shrink-0 justify-start gap-3 px-3 text-sm hover:bg-sidebar-accent hover:text-sidebar-accent-foreground", section === s && "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary hover:text-sidebar-primary-foreground")}><I />{SECTION_LABELS[s]}</Button>; })}
        </nav>
        <div className="space-y-1 border-t border-sidebar-border p-3"><Button asChild variant="ghost" className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-foreground"><Link to="/farms"><ArrowLeftRight /> Switch practice</Link></Button><Button variant="ghost" className="w-full justify-start hover:bg-sidebar-accent hover:text-sidebar-foreground" onClick={() => supabase.auth.signOut()}><LogOut /> Sign out</Button></div>
      </aside>
      <div className="min-w-0">
        <header className="flex h-16 items-center justify-between gap-3 border-b bg-card px-5 md:px-8"><div className="flex min-w-0 items-center gap-2 text-xs text-muted-foreground"><span className="truncate">{farm.name}</span><ChevronRight className="h-3 w-3 shrink-0" /><span className="font-semibold text-foreground">{SECTION_LABELS[section]}</span></div><span className="shrink-0 rounded-md bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground">{p.label}</span></header>
        <main className="mx-auto max-w-7xl px-5 py-7 md:px-8">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-3"><div><h1 className="text-3xl font-bold">{SECTION_LABELS[section] === "Dashboard" ? "Farm overview" : SECTION_LABELS[section]}</h1><div className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{farm.location || farm.name}</div></div><p className="text-xs text-muted-foreground">{new Date().toLocaleDateString("en-KE", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p></div>
          {section === "overview" && <Overview {...props} onNavigate={selectSection} />}
          {section === "flock" && <FlockSection {...props} />}
          {section === "eggs" && <EggSection {...props} />}
          {section === "sales" && <SalesSection {...props} />}
          {section === "feed" && <FeedSection {...props} />}
          {section === "treatments" && <TreatmentSection {...props} />}
          {section === "finance" && <FinanceSection {...props} />}
          {section === "activities" && <ActivitySection {...props} />}
          {section === "profile" && <ProfileSection farm={farm} onDeleted={() => navigate({ to: "/farms" })} />}
        </main>
      </div>
    </div>
  );
}
