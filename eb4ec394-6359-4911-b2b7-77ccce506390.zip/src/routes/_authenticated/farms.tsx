import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Egg, LogOut, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PRACTICES, type Practice } from "@/lib/practices";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/farms")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "My farms — Kuku Ledger" },
      { name: "description", content: "Choose a chicken practice and open its dashboard." },
      { property: "og:title", content: "My farms — Kuku Ledger" },
      { property: "og:description", content: "Choose a chicken practice and open its dashboard." },
    ],
  }),
  component: FarmsPage,
});

function FarmsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const farms = useQuery({
    queryKey: ["farms"],
    queryFn: async () => {
      const { data, error } = await supabase.from("farms").select("*").order("created_at");
      if (error) throw error;
      return data;
    },
  });
  const [practice, setPractice] = useState<Practice | null>(null);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");

  const create = useMutation({
    mutationFn: async () => {
      if (!practice) throw new Error("Choose a practice first");
      const { data, error } = await supabase
        .from("farms")
        .insert({ practice, name: name.trim(), location: location.trim() || null })
        .select("id")
        .single();
      if (error) throw error;
      return data.id;
    },
    onSuccess: (id) => {
      qc.invalidateQueries({ queryKey: ["farms"] });
      navigate({ to: "/farm/$farmId", params: { farmId: id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="min-h-screen">
      <header className="bg-hero text-primary-foreground">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 font-display text-xl font-bold"><Egg className="h-6 w-6 text-accent" /> Kuku Ledger</div>
          <Button variant="hero" size="sm" onClick={() => supabase.auth.signOut()}><LogOut /> Sign out</Button>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-6 py-10">
        {farms.data && farms.data.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold">Your farms</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2 md:grid-cols-3">
              {farms.data.map((f) => (
                <Link key={f.id} to="/farm/$farmId" params={{ farmId: f.id }} className="rounded-2xl border bg-card p-5 shadow-soft transition hover:-translate-y-0.5">
                  <div className="text-3xl">{PRACTICES[f.practice].emoji}</div>
                  <div className="mt-2 font-display text-lg font-bold">{f.name}</div>
                  <div className="text-sm text-muted-foreground">{PRACTICES[f.practice].label}{f.location ? ` · ${f.location}` : ""}</div>
                </Link>
              ))}
            </div>
          </section>
        )}

        <section>
          <h1 className="text-3xl font-bold">{farms.data?.length ? "Start another practice" : "What kind of chickens do you keep?"}</h1>
          <p className="mt-1 text-muted-foreground">Pick a practice — your dashboard will be set up for it.</p>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {(Object.keys(PRACTICES) as Practice[]).map((k) => (
              <button
                key={k}
                onClick={() => { setPractice(k); if (!name) setName(`My ${PRACTICES[k].label} farm`); }}
                className={cn(
                  "rounded-2xl border-2 bg-card p-6 text-left transition",
                  practice === k ? "border-primary shadow-soft" : "border-transparent hover:border-border",
                )}
              >
                <div className="text-4xl">{PRACTICES[k].emoji}</div>
                <div className="mt-3 font-display text-xl font-bold">{PRACTICES[k].label}</div>
                <p className="mt-1 text-sm text-muted-foreground">{PRACTICES[k].tagline}</p>
              </button>
            ))}
          </div>
          {practice && (
            <form
              onSubmit={(e) => { e.preventDefault(); if (name.trim()) create.mutate(); }}
              className="mt-6 grid gap-4 rounded-2xl border bg-card p-6 md:grid-cols-[1fr_1fr_auto] md:items-end"
            >
              <div className="space-y-1.5"><Label>Farm name</Label><Input required value={name} onChange={(e) => setName(e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Location</Label><Input placeholder="e.g. Kiambu" value={location} onChange={(e) => setLocation(e.target.value)} /></div>
              <Button type="submit" disabled={create.isPending}><Plus /> Create dashboard</Button>
            </form>
          )}
        </section>
      </main>
    </div>
  );
}
