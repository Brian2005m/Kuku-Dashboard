/** Scheduling labels only: no doses, administration instructions, or automatic recommendations. */
export const TREATMENT_GROUPS = [
  { label: "Vaccines", options: ["Newcastle vaccine (Lasota)", "Gumboro vaccine", "Fowl pox vaccine", "Marek’s disease vaccine", "Infectious bronchitis vaccine", "Fowl typhoid vaccine"] },
  { label: "Other treatments", options: ["Deworming", "External parasite treatment", "Vitamin / electrolyte supplement"] },
];

export function selectedTreatment(selection: string, customName: string): string {
  const name = selection === "other" ? customName.trim() : selection;
  if (!name) throw new Error("Choose a treatment or enter its name");
  if (selection !== "other" && !TREATMENT_GROUPS.some((group) => group.options.includes(selection))) throw new Error("Choose a treatment from the list");
  return name;
}