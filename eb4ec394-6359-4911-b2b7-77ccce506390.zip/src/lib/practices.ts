export type Practice = "layers" | "broilers" | "kienyeji";

export type Section =
  | "overview"
  | "flock"
  | "eggs"
  | "sales"
  | "feed"
  | "treatments"
  | "finance"
  | "activities"
  | "profile";

export const PRACTICES: Record<
  Practice,
  { label: string; tagline: string; emoji: string; sections: Section[]; products: string[] }
> = {
  layers: {
    label: "Layers",
    tagline: "Egg production — track daily collection, quotas and crate sales.",
    emoji: "🥚",
    sections: ["overview", "flock", "eggs", "sales", "feed", "treatments", "finance", "activities", "profile"],
    products: ["Egg crates", "Spent hens", "Manure"],
  },
  broilers: {
    label: "Broilers",
    tagline: "Meat birds — monitor batches, feed conversion and bird sales.",
    emoji: "🍗",
    sections: ["overview", "flock", "sales", "feed", "treatments", "finance", "activities", "profile"],
    products: ["Live birds", "Dressed birds", "Manure"],
  },
  kienyeji: {
    label: "Kienyeji",
    tagline: "Free-range indigenous — eggs, chicks and birds from one flock.",
    emoji: "🐓",
    sections: ["overview", "flock", "eggs", "sales", "feed", "treatments", "finance", "activities", "profile"],
    products: ["Eggs", "Live birds", "Chicks", "Manure"],
  },
};

export const SECTION_LABELS: Record<Section, string> = {
  overview: "Dashboard",
  flock: "Flock",
  eggs: "Egg production",
  sales: "Sales",
  feed: "Feed",
  treatments: "Treatments",
  finance: "Finance",
  activities: "Activities",
  profile: "Farm profile",
};

/** Age in whole weeks from an arrival date (ISO yyyy-mm-dd) to `today`. */
export function ageInWeeks(arrival: string, today: Date = new Date()): number {
  const ms = today.getTime() - new Date(arrival + "T00:00:00").getTime();
  return Math.max(0, Math.floor(ms / (7 * 24 * 3600 * 1000)));
}

/** Feed stock = purchases − consumption, never below zero. */
export function feedStock(logs: { kind: string; quantity_kg: number }[]): number {
  const v = logs.reduce((s, l) => s + (l.kind === "purchase" ? 1 : -1) * Number(l.quantity_kg), 0);
  return Math.max(0, v);
}

/** Percentage of quota achieved, rounded; 0 when quota is 0. */
export function quotaPercent(eggs: number, quota: number): number {
  return quota > 0 ? Math.round((eggs / quota) * 100) : 0;
}

export const kes = (n: number) =>
  "KES " + Number(n || 0).toLocaleString("en-KE", { maximumFractionDigits: 0 });

export const today = () => new Date().toISOString().slice(0, 10);
