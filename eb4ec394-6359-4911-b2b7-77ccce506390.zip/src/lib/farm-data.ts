import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Tables = Database["public"]["Tables"];
// Generic table access: the typed client cannot narrow column names over a union of tables.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as unknown as { from: (t: RecordTable) => any };
export type RecordTable = Exclude<keyof Tables, "farms">;
export type Row<T extends keyof Tables> = Tables[T]["Row"];

export function useRecords<T extends RecordTable>(table: T, farmId: string) {
  return useQuery({
    queryKey: [table, farmId],
    queryFn: async () => {
      const { data, error } = await db
        .from(table)
        .select("*")
        .eq("farm_id", farmId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as Row<T>[];
    },
  });
}

export function useRecordMutations<T extends RecordTable>(table: T, farmId: string) {
  const qc = useQueryClient();
  const refresh = () => {
    qc.invalidateQueries({ queryKey: [table, farmId] });
    if (table === "mortalities") qc.invalidateQueries({ queryKey: ["flocks", farmId] });
  };
  const onError = (e: Error) => toast.error(e.message);
  const add = useMutation({
    mutationFn: async (values: Omit<Tables[T]["Insert"], "farm_id">) => {
      const { error } = await db.from(table).insert({ ...values, farm_id: farmId } as never);
      if (error) throw error;
    },
    onSuccess: () => { refresh(); toast.success("Saved"); },
    onError,
  });
  const update = useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Tables[T]["Update"] }) => {
      const { error } = await db.from(table).update(values as never).eq("id", id);
      if (error) throw error;
    },
    onSuccess: refresh,
    onError,
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from(table).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: refresh,
    onError,
  });
  return { add, update, remove };
}

export function useFarm(farmId: string) {
  return useQuery({
    queryKey: ["farm", farmId],
    queryFn: async () => {
      const { data, error } = await supabase.from("farms").select("*").eq("id", farmId).single();
      if (error) throw error;
      return data;
    },
  });
}
