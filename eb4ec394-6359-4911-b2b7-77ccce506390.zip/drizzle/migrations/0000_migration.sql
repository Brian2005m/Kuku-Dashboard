CREATE TYPE public.practice_type AS ENUM ('layers','broilers','kienyeji');

CREATE TABLE public.farms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  practice practice_type NOT NULL,
  name text NOT NULL,
  location text,
  size text,
  established date,
  contact text,
  egg_quota integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.flocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  name text NOT NULL, initial_count integer NOT NULL CHECK (initial_count >= 0),
  current_count integer NOT NULL CHECK (current_count >= 0),
  arrival_date date NOT NULL DEFAULT current_date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.mortalities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  flock_id uuid NOT NULL REFERENCES public.flocks(id) ON DELETE CASCADE,
  count integer NOT NULL CHECK (count > 0), reason text, date date NOT NULL DEFAULT current_date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.egg_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  eggs integer NOT NULL CHECK (eggs >= 0), quota integer NOT NULL DEFAULT 0, date date NOT NULL DEFAULT current_date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  product text NOT NULL, quantity numeric NOT NULL CHECK (quantity > 0), unit_price numeric NOT NULL CHECK (unit_price >= 0),
  date date NOT NULL DEFAULT current_date, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.feed_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('purchase','consumption')), feed_type text NOT NULL,
  quantity_kg numeric NOT NULL CHECK (quantity_kg > 0), cost numeric NOT NULL DEFAULT 0,
  date date NOT NULL DEFAULT current_date, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.treatments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  name text NOT NULL, flock_name text, due_date date NOT NULL, done boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  category text NOT NULL, description text, amount numeric NOT NULL CHECK (amount >= 0),
  date date NOT NULL DEFAULT current_date, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  farm_id uuid NOT NULL REFERENCES public.farms(id) ON DELETE CASCADE,
  title text NOT NULL, description text, date date NOT NULL, time time, done boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['farms','flocks','mortalities','egg_records','sales','feed_logs','treatments','expenses','activities'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY "own rows" ON public.%I FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid())', t);
    EXECUTE format('CREATE INDEX ON public.%I (user_id)', t);
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.apply_mortality() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  UPDATE public.flocks SET current_count = GREATEST(current_count - NEW.count, 0)
  WHERE id = NEW.flock_id AND user_id = auth.uid();
  RETURN NEW;
END $$;
CREATE TRIGGER mortality_reduce AFTER INSERT ON public.mortalities FOR EACH ROW EXECUTE FUNCTION public.apply_mortality();